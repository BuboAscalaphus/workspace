#!/bin/bash

# Define directories and file paths
TARGET_DIR=share/vizionsdk
RULES_FILE=/etc/udev/rules.d/88-cyusb.rules
CONF_FILE=/etc/cyusb.conf
SCRIPT_FILE=/usr/local/bin/cy_renumerate.sh

# Ensure script runs with root privileges
if [ "$(id -u)" -ne 0 ]; then
    echo "Please run this script with root privileges"
    exit 1
fi

# Copy files, overwrite if they exist
echo "Installing udev rules..."
cp -f "$TARGET_DIR/driver/88-cyusb.rules" "$RULES_FILE"

echo "Installing configuration file..."
cp -f "$TARGET_DIR/driver/cyusb.conf" "$CONF_FILE"

echo "Installing utility script..."
cp -f "$TARGET_DIR/driver/cy_renumerate.sh" "$SCRIPT_FILE"
chmod 777 "$SCRIPT_FILE"

echo "Installation complete!"
