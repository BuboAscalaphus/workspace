import pyvizionsdk
from pyvizionsdk import VX_CAMERA_INTERFACE_TYPE, VX_CAMERA_PRODUCT_TYPE, VX_IMAGE_FORMAT, VX_ISP_IMAGE_PROPERTIES, VX_OSP_PROFILE_FLAG, VX_CAPTURE_RESULT

import inquirer
from inquirer.themes import BlueComposure
import os, sys
import numpy as np

if os.name == "posix":
    import termios


class pyVizionCtl:

    def clearConsole(self):
        return os.system("cls" if os.name in ("nt", "dos") else "clear")

    def DisableEcho(self):
        '''
        prevent special characters appear '^ [[' during continuous pressing of up or down
        '''
        if os.name == "posix":
            fd = sys.stdin.fileno()
            old = termios.tcgetattr(fd)
            new = termios.tcgetattr(fd)
            new[3] = new[3] & ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSADRAIN, new)
            return old
        else:
            return None

    def EnableEcho(self, old):
        if os.name == "posix":
            fd = sys.stdin.fileno()
            termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def OptionTerminal(self, options):
        '''
        Restored echo state after the prompt, regardless of success or failure. 
        '''
        old = self.DisableEcho()
        try:
            result = inquirer.prompt(options, theme=BlueComposure())
            if result:
                return result
            else:
                print("Prompt cancelled or no selection. Exiting...")
                sys.exit(0)
        except Exception as e:
            print(f"Error during prompt: {e}")
            return None
        finally:
            self.EnableEcho(old)

    def GetDeviceList(self):
        result, camera_list = pyvizionsdk.VxDiscoverCameraDevices()
        cameras = []
        for camera in camera_list:
            cameras.append(camera)

        if len(cameras) == 0:
            self.clearConsole()
            options = [
                inquirer.List('pyVizionCtl',
                              message="No Camera detected! Please exit.",
                              choices=["exit"],
                              carousel=True),
            ]
            result = self.OptionTerminal(options)
            entryIndex = result['pyVizionCtl']

            if entryIndex == "exit":
                exit()
        else:
            self.clearConsole()
            options = [
                inquirer.List('pyVizionCtl',
                              message="Cameras List",
                              choices=cameras,
                              carousel=True),
            ]
            result = self.OptionTerminal(options)
            dev = result['pyVizionCtl']
            devIndex = cameras.index(dev)
            cam = self.InitialDev(devIndex)
            self.CtlList(cam)

    def InitialDev(self, devIndex):
        # initial the device and open the camera
        cam = pyvizionsdk.VxInitialCameraDevice(devIndex)
        pyvizionsdk.VxOpen(cam)
        return cam

    def CtlList(self, cam):
        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="Camera Control and Management Tool",
                          choices=[
                              "Device Information", "Camera Control",
                              "List Formats", "Image operations",
                              "OSP Profile management", "Timestamp operations",
                              "Sensor config operations",
                              " < Back to Device List", "exit"
                          ],
                          carousel=True),
        ]

        result = self.OptionTerminal(options)
        ctlIndex = result['pyVizionCtl']

        #Device Information
        if ctlIndex == "Device Information":
            return self.DeviceInfo(cam)
        # Camera Control
        elif ctlIndex == "Camera Control":
            return self.CameraControl(cam)
        # List Formats
        elif ctlIndex == "List Formats":
            return self.FormatList(cam)
        # Image operations
        elif ctlIndex == "Image operations":
            return self.ImageOperation(cam)
        # OSP Profile management
        elif ctlIndex == "OSP Profile management":
            return self.OSPProfile(cam)
        # Timestamp operations
        elif ctlIndex == "Timestamp operations":
            return self.Timestamp(cam)
        # Sensor config operations
        elif ctlIndex == "Sensor config operations":
            return self.SensorConfig(cam)
        # Back to Device List
        elif ctlIndex == " < Back to Device List":
            pyvizionsdk.VxClose(cam)
            return self.GetDeviceList()
        # exit
        elif ctlIndex == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetFWVersion(self, cam, interface, camtype):
        # get info by interface
        if interface == VX_CAMERA_INTERFACE_TYPE.INTERFACE_USB:
            typeStr = "USB"
            _, usbFwVer = pyvizionsdk.VxGetUSBFirmwareVersion(cam)
            _, hwId = pyvizionsdk.VxGetHardwareID(cam)
            print("HardWareID: ", hwId)
            print("Interface Type: ", typeStr)
            print("USB Firmware: ", usbFwVer)
        elif interface == VX_CAMERA_INTERFACE_TYPE.INTERFACE_MIPI_CSI2:
            typeStr = "Sensor"
            print("Interface Type: ", typeStr)
        else:
            typeStr = "Unknown"
            print("Interface Type: ", typeStr)

        # get info by camera type
        if camtype == VX_CAMERA_PRODUCT_TYPE.VXCAM_PRODUCT_TYPE_TEVI:
            _, fwVer = pyvizionsdk.VxGetSensorFirmwareVersion(cam)
            print("Sensor Firmware: ", fwVer)
        elif camtype == VX_CAMERA_PRODUCT_TYPE.VXCAM_PRODUCT_TYPE_TEVS:
            _, fwVer = pyvizionsdk.VxGetTEVSFirmwareVersion(cam)
            print("Sensor Firmware: ", fwVer)

    def DeviceInfo(self, cam):
        self.clearConsole()
        print("Device Information:")
        _, devName = pyvizionsdk.VxGetDeviceName(cam)
        print("Device Name: ", devName)

        # get information
        if pyvizionsdk.VxIsVizionCamera(cam) == 0:
            _, tyname = pyvizionsdk.VxGetDeviceInterfaceType(cam)
            _, camtype = pyvizionsdk.VxGetDeviceProductType(cam)
            self.GetFWVersion(cam, tyname, camtype)

        # device information menu
        options = [
            inquirer.List('pyVizionCtl',
                          choices=[
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # select other control
        if index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def CameraControl(self, cam):
        controls = {
            "Brightness": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_BRIGHTNESS,
            "Contrast": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_CONTRAST,
            "Saturation": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_SATURATION,
            "Gamma": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_GAMMA,
            "Sharpness": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_SHARPNESS,
            "Backlight":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_BACKLIGHT_COMPENSATION,
            "Noise": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_DENOISE,
            "White_Balance_Mode":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_WHITEBALANCE_MODE,
            "White_Balance_Temperature":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_WHITEBALANCE_TEMPERATURE,
            "JPEG_Quality": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_JPEG_QUALITY,
            "Exposure_Mode": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EXPOSURE_MODE,
            "Exposure_Time": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EXPOSURE_TIME,
            "Exposure_Min_Time":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EXPOSURE_MIN_TIME,
            "Exposure_Max_Time":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EXPOSURE_MAX_TIME,
            "Exposure_Gain": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EXPOSURE_GAIN,
            "Flick_Mode": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_FLICK_MODE,
            "Special_Effect":
            VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_SPECIAL_EFFECT_MODE,
            "Flip_Mode": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_FLIP_MODE,
            "Pan_Target": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_PAN,
            "Tilt_Target": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_TILT,
            "Zoom_Target": VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_ZOOM,
            "Throughput": pyvizionsdk.VxGetThroughPut(cam),
            "Max_FPS": pyvizionsdk.VxGetMaxFPS(cam)
        }

        result, interType = pyvizionsdk.VxGetDeviceInterfaceType(cam)
        if result == 0:
            if interType == VX_CAMERA_INTERFACE_TYPE.INTERFACE_MIPI_CSI2:
                controls[
                    "Trigger_mode"] = VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_TRIGGER_MODE
        
        result, interType = pyvizionsdk.VxGetDeviceProductType(cam)
        ret , deviceName = pyvizionsdk.VxGetDeviceName(cam)
        if result == 0 and ret == 0:
            if interType == VX_CAMERA_PRODUCT_TYPE.VXCAM_PRODUCT_TYPE_TEVI or interType == VX_CAMERA_PRODUCT_TYPE.VXCAM_PRODUCT_TYPE_TEVS:
                if deviceName.find("AR0821") != -1 or deviceName.find("AR0822") != -1:
                    controls["eHDR_mode"] = VX_ISP_IMAGE_PROPERTIES.ISP_IMAGE_EHDR_MODE
                    controls["eHDR_exposure_min_number"] = VX_ISP_IMAGE_PROPERTIES.ISP_EHDR_EXPOSURE_MIN_NUMBER
                    controls["eHDR_exposure_max_number"] = VX_ISP_IMAGE_PROPERTIES.ISP_EHDR_EXPOSURE_MAX_NUMBER

        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="Camera Control",
                          choices=[
                              "Get Controls", "Set Controls",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # get controls
        if index == "Get Controls":
            return self.GetControl(cam, controls)
        # set controls
        elif index == "Set Controls":
            self.clearConsole()
            return self.SetControl(cam, controls)
        # select other control
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetControl(self, cam, controls):
        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="Get Controls",
                          choices=[
                              "Get all controls value",
                              "Get specific control value",
                              " < Back to Camera Control Menu", "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Get all controls
        if index == "Get all controls value":
            self.clearConsole()
            self.GetAllControl(cam, controls)
            options = [
                inquirer.List('pyVizionCtl',
                              choices=[
                                  " < Back to Get Controls Menu",
                                  " << Back to Camera Control Menu", "exit"
                              ],
                              carousel=True),
            ]
            result = self.OptionTerminal(options)
            index = result['pyVizionCtl']

            # Back to Get Control Menu
            if index == " < Back to Get Controls Menu":
                return self.GetControl(cam, controls)
            # Back to Camera Control Menu
            elif index == " << Back to Camera Control Menu":
                return self.CameraControl(cam)
            # exit
            elif index == "exit":
                # close the camera when exit
                self.clearConsole()
                pyvizionsdk.VxClose(cam)
                exit()
        # Get specific control
        elif index == "Get specific control value":
            return self.GetSpecificControl(cam, controls)
        # Back to Camera Control Menu
        elif index == " < Back to Camera Control Menu":
            return self.CameraControl(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetAllControl(self, cam, controls):
        print("Available controls:")
        print("=============================================================")
        for enum, (propName, propId) in enumerate(controls.items()):
            if propName == "Throughput":
                throughput = propId[1]
                print(
                    f"[{enum:2}] {propName:25} {throughput:>8} | {10.0:>8.2f} - {1000.0:<8.2f}"
                )
            elif propName == "Max_FPS":
                maxFPS = propId[1]
                print(
                    f"[{enum:2}] {propName:25} {maxFPS:>8} | {1:>8} - {120:<8}"
                )
            else:
                ret, value, flag = pyvizionsdk.VxGetISPImageProcessing(
                    cam, propId)
                if ret == -1:
                    print(f"Failed to get [{enum}]: {propName}")
                    continue

                minVal, maxVal = pyvizionsdk.VxGetISPImageProcessingRange(
                    cam, propId)[1:3]
                if flag == 1:
                    print(f"{propName} control is read-only")
                    print(
                        f"[{enum:2}] {propName:25} {value:>8} | {minVal:>8} - {maxVal:<8} (Read-only)"
                    )
                else:
                    print(
                        f"[{enum:2}] {propName:25} {value:>8} | {minVal:>8} - {maxVal:<8}"
                    )

            if propName == "White_Balance_Mode":
                print(f"{'':39} | {'':>6} Manual Temperature(0), Auto(1)")
            elif propName == "Exposure_Mode":
                print(
                    f"{'':39} | {'':>6} Manual Mode(0), Auto Mode(1), Auto gain(2)"
                )
            elif propName == "Flick_Mode":
                print(
                    f"{'':39} | {'':>6} Disable(0), 50Hz(1), 60Hz(2), Auto(3)")
            elif propName == "Special_Effect":
                print(
                    f"{'':39} | {'':>6} Normal Mode(0), Black White Mode(1), Grayscale Mode(2), Negative Mode(3), Sketch Mode(4)"
                )
            elif propName == "Flip_Mode":
                print(
                    f"{'':39} | {'':>6} Normal(0), H-Mirror(1), V-Mirror(2), Rotate-180(3)"
                )
            elif propName == "Trigger_Mode":
                print(
                    f"{'':39} | {'':>6} Disable(0), Sync(1), Periodic(2), Non Periodic(3)"
                )
            elif propName == "eHDR_Mode":
                print(
                    f"{'':39} | {'':>6} Enable(0), Disable(1)"
                )

    def GetValidIndex(self, prompt, maxIdx):
        while True:
            index = input(prompt)
            if not index.isdigit():
                print("The input must be a positive integer.")
                continue

            index = int(index)
            if index > maxIdx-1:
                print("The property index is out of range!")
                continue

            return index
    
    
    def GetSpecificControl(self, cam, controls):
        self.clearConsole()

        for enum, prop in enumerate(controls):
            print(f"[{enum}] {prop}")
        prompt = "\nEnter a property index: "
        propIndex = self.GetValidIndex(prompt, len(controls))

        propName = list(controls)[propIndex]
        propId = list(controls.values())[propIndex]
        print("{:25} {:>8} | {:>8}".format("Name", "Value", "Range"))
        if propName == "Throughput":
            throughput = propId[1]
            print(
                f"{propName:25} {throughput:>8} | {10.0:>8.2f} - {1000.0:<8.2f}"
            )
        elif propName == "Max_FPS":
            maxFPS = propId[1]
            print(f"{propName:25} {maxFPS:>8} | {1:>8} - {120:<8}")
        else:
            ret, value, flag = pyvizionsdk.VxGetISPImageProcessing(
                cam, propId)
            if ret == -1:
                print(f"Failed to get {propName}")
            else:
                minVal, maxVal = pyvizionsdk.VxGetISPImageProcessingRange(
                    cam, propId)[1:3]
                if flag == 1:
                    print(f"{propName} control is read-only")
                    print(
                        f"{propName:25} {value:>8} | {minVal:>8} - {maxVal:<8} (Read-only)"
                    )
                else:
                    print(
                        f"{propName:25} {value:>8} | {minVal:>8} - {maxVal:<8}"
                    )


        options = [
            inquirer.List('pyVizionCtl',
                          choices=[
                              " < Back to Get Controls Menu",
                              " << Back to Camera Control Menu", "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Get Control Menu
        if index == " < Back to Get Controls Menu":
            return self.GetControl(cam, controls)
        # Back to Camera Control Menu
        elif index == " << Back to Camera Control Menu":
            return self.CameraControl(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def ValidProperty(self, propName, minVal, maxVal):
        while True:
            value = input(f"\n(Range of {propName}: {minVal}-{maxVal})\nEnter a value: ")
            if not value:
                print("The input cannot be empty.")
                continue

            try:
                value = int(value)
            except ValueError:
                print("The input must be a number.")
                continue

            value = int(value)

            if value < minVal or value > maxVal:
                print(f"The value is out of range. {propName} Range: {minVal}-{maxVal}")
                continue

            return value


    def SetControl(self, cam, controls):
        self.GetAllControl(cam, controls)
        prompt = "\nEnter a property index: "
        propIndex = self.GetValidIndex(prompt, len(controls))
        
        propName = list(controls)[propIndex]
        propId = list(controls.values())[propIndex]

        if propName == "Throughput":
            minVal = 10.00
            maxVal = 1000.00
        elif propName == "Max_FPS":
            minVal = 1
            maxVal = 120
        else:
            ret, value, flag = pyvizionsdk.VxGetISPImageProcessing(cam, propId)
            # To check is read only or not 
            if flag == 1:
                self.clearConsole()
                print(f"{propName} control is read-only")
                return self.SetControl(cam, controls)
            elif ret == -1:
                self.clearConsole()
                print(f"{propName} fail to be set")
                return self.SetControl(cam, controls)
            else:
                minVal, maxVal = pyvizionsdk.VxGetISPImageProcessingRange(
                cam, propId)[1:3]
            
        value = self.ValidProperty(propName, minVal, maxVal)

        if propName == "Throughput":
            pyvizionsdk.VxSetThroughPut(cam, value)
        elif propName == "Max_FPS":
            pyvizionsdk.VxSetMaxFPS(cam, value)
        else:
            result = pyvizionsdk.VxSetISPImageProcessing(cam, propId, value)
            if result == 0:
                print("Set Successfully!")
            else:
                print(f"Fail to set {propName}")

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[" < Back to Camera Control Menu", "exit"],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Camera Control Menu
        if index == " < Back to Camera Control Menu":
            return self.CameraControl(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def FormatList(self, cam):
        self.clearConsole()
        formatList, formats = self.GetFormatList(cam)
        options = [
            inquirer.List('pyVizionCtl',
                          message="Format List",
                          choices=[
                              "Set format",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to set format
        if index == "Set format":
            if self.SetFormat(cam, formatList, formats)[0] == 0:
                options = [
                    inquirer.List(
                        'pyVizionCtl',
                        choices=[
                            " << Back to Camera Control and Management Tool",
                            "exit"
                        ],
                        carousel=True),
                ]
                result = self.OptionTerminal(options)
                index = result['pyVizionCtl']

                # Back to Format List
                if index == " << Back to Camera Control and Management Tool":
                    return self.CtlList(cam)
                # exit
                elif index == "exit":
                    # close the camera when exit
                    self.clearConsole()
                    pyvizionsdk.VxClose(cam)
                    exit()

        # Back to Camera Control and Management Tool
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def FormattoStr(self, format):
        if format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_YUY2:
            return "YUY2"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_UYVY:
            return "UYVY"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_NV12:
            return "NV12"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_MJPG:
            return "MJPG"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_BGRA:
            return "BGRA"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_BGRX:
            return "BGRX"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_BGR:
            return "BGR"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_RGB16:
            return "RGB16"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_RGB:
            return "RGB"
        elif format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_NONE:
            return "UNKNOWN"

    def GetFormatList(self, cam):
        # display th format list
        result, fmts = pyvizionsdk.VxGetFormatList(cam)
        formats = []
        formatList = []
        i = 0
        for format in fmts:
            # remove the None format
            if format.format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_NONE:
                continue
            fmt = self.FormattoStr(format.format)
            formatStr = f"[{i:2}]: {format.width:5} x {format.height:>4} {fmt:>5} {format.framerate:>4}fps"
            print(formatStr)
            formats.append(formatStr)
            formatList.append(format)
            i += 1
        return formatList, formats

    def SetFormat(self, cam, formatList, formats):
        prompt = "\nChoose a format index: "
        index = self.GetValidIndex(prompt, len(formatList))

        self.clearConsole()
        result = pyvizionsdk.VxSetFormat(cam, formatList[index])
        if result == 0:
            print("Set Format Success: \n", formats[index])
        else:
            print("Fail to Set Format.\n")
        
        return result, formatList[index]

    def ImageOperation(self, cam):
        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="Image Operation",
                          choices=[
                              "Save Image",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # save image
        if index == "Save Image":
            return self.SaveImage(cam)
        # select other control
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def ValidFilePath(self, filePath, typeName):
        imgExt = ["npy", "raw"]
        jpgExt = ["jpg", "jpeg"]

        if not filePath or not isinstance(filePath, str):
            print("File Path must be a non-empty string.")
            return False
        elif '.' not in filePath:
            print("Filename must include a file extension.")
            return False
        else:
            fileName, exten = filePath.rsplit('.', 1)
            if typeName == "img" and exten not in imgExt:
                print("Filename must include a file extension.(npy, raw)")
                return False
            elif typeName == "jpg" and exten not in imgExt and exten not in jpgExt:
                print("Filename must include a file extension.(npy, raw, jpg, jpeg)")
                return False
            elif typeName == "bin" and exten != "bin":
                print("Filename must include a file extension.(bin)")
                return False
            elif typeName == "json" and exten != "json":
                print("Filename must include a file extension.(json)")
                return False

        return True

    def SaveImage(self, cam):
        self.clearConsole()
        formatList, formats = self.GetFormatList(cam)
        result, imgFormat = self.SetFormat(cam, formatList, formats)

        if result == 0:
            if imgFormat.format == VX_IMAGE_FORMAT.VX_IMAGE_FORMAT_MJPG:
                typeName = "jpg"
                print("Valid extension: npy, raw, jpg, jpeg")
            else:
                typeName = "img"
                print("Valid extension: npy, raw")
            
            filePath = input("Enter the File Path (e.g: test.raw): ")
            while not self.ValidFilePath(filePath, typeName):
                filePath = input("Enter the File Path (e.g: test.raw): ")

            while True:
                imgSkip = input("Enter the numbers of image to skip: ")
                if imgSkip.isdigit():
                    imgSkip = int(imgSkip)
                    if imgSkip >= 0:
                        break
                    else:
                        print("Number is invalid, please enter the number >= 0.")
                else:
                    print("The input string contains non-digit characters.")

            while True:
                imgSave = input("Enter the numbers of image to save: ")
                if imgSave.isdigit():
                    imgSave = int(imgSave)
                    if imgSave > 0:
                        break
                    else:
                        print("Number is invalid, please enter the number > 0.")
                else:
                    print("The input string contains non-digit characters.")

            pyvizionsdk.VxStartStreaming(cam)

            for s in range(1, imgSkip + 1):
                print("Skip ", s)
                result, imgArr = pyvizionsdk.VxGetImage(cam, 3000, imgFormat)
                if result != VX_CAPTURE_RESULT.VX_SUCCESS:
                    print("Failed to get image during skip.")
                    break

            for i in range(1, imgSave + 1):
                result, imgArr = pyvizionsdk.VxGetImage(cam, 3000, imgFormat)
                if result != VX_CAPTURE_RESULT.VX_SUCCESS:
                    print("Failed to save image.")
                    break

                if imgSave > 1:
                    fileName, extension = filePath.rsplit('.', 1)
                    newfilePath = fileName + '_' + str(i) + '.' + extension
                    try:
                        imgArr.tofile(newfilePath)
                        print(f"Save the image to {newfilePath}")
                    except (OSError, ValueError) as e:
                        print(f"Error to save the image: {e}")
                        break
                else:
                    try:
                        imgArr.tofile(filePath)
                        print(f"Save the image to {filePath}")
                    except (OSError, ValueError) as e:
                        print(f"Error to save the image: {e}")
                        break

            pyvizionsdk.VxStopStreaming(cam)

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[
                              " << Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # select other control
        if index == " << Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def OSPProfile(self, cam):
        flagType = {
            VX_OSP_PROFILE_FLAG.DISABLED: "DISABLED",
            VX_OSP_PROFILE_FLAG.ENABLED: "ENABLED",
            VX_OSP_PROFILE_FLAG.ENABLED_AND_SAVE: "ENABLE_AND_SAVE"
        }
        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="OSP Profile Management",
                          choices=[
                              "Get OSP Flag", "Set OSP Flag",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # get OSP flag
        if index == "Get OSP Flag":
            return self.GetOSPFlag(cam, flagType)
        # set OSP flag
        elif index == "Set OSP Flag":
            return self.SetOSPFlag(cam, flagType)
        # select other control
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetOSPFlag(self, cam, flagType):
        self.clearConsole()
        flag = pyvizionsdk.VxGetOSPProfileFlag(cam)[1]
        flagStr = flagType[flag]
        print("OSP Profile Flag: ", flagStr)

        options = [
            inquirer.List(
                'pyVizionCtl',
                message="OSP Profile Management",
                choices=[" < Back to OSP Profile Management", "exit"],
                carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to OSP Profile Management
        if index == " < Back to OSP Profile Management":
            return self.OSPProfile(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def SetOSPFlag(self, cam, flagType):
        self.clearConsole()
        options = [
            inquirer.List('setOSP',
                          choices=[option for option in flagType.values()],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        ftype = result['setOSP']

        flagIndex = (list(flagType.values())).index(ftype)
        # DISABLED ENABLED ENABLED_AND_SAVE
        pyvizionsdk.VxSetOSPProfileFlag(cam, list(flagType)[flagIndex])
        print("Set OSP Profile Successful!")

        ospOptions = [
            inquirer.List(
                'pyVizionCtl',
                message="OSP Profile Management",
                choices=[" < Back to OSP Profile Management", "exit"],
                carousel=True),
        ]
        result = self.OptionTerminal(ospOptions)
        ospIndex = result['pyVizionCtl']

        # Back to OSP Profile Management
        if ospIndex == " < Back to OSP Profile Management":
            return self.OSPProfile(cam)
        # exit
        elif ospIndex == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def Timestamp(self, cam):
        self.clearConsole()
        print(
            "[!] The reset functions must be used when the camera is streaming."
        )
        options = [
            inquirer.List('pyVizionCtl',
                          message="Timestamp Operations:",
                          choices=[
                              "Get Timestamp", "Get FrameCount",
                              "Reset Timestamp", "Reset FrameCount",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # get timestamp
        if index == "Get Timestamp":
            return self.GetTimestamp(cam)
        # get framecount
        elif index == "Get FrameCount":
            return self.GetFrameCount(cam)
        # reset timestamp
        elif index == "Reset Timestamp":
            return self.ResetTimestamp(cam)
        # reset framecount
        elif index == "Reset FrameCount":
            return self.ResetFrameCount(cam)
        # select other control
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetTimestamp(self, cam):
        self.clearConsole()
        timestamp = pyvizionsdk.VxGetTimestamp(cam)[1]
        print(f"Timestamp: {timestamp}\n")

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[" < Back to Timestamp Operations", "exit"],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Timestamp Operations
        if index == " < Back to Timestamp Operations":
            return self.Timestamp(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def GetFrameCount(self, cam):
        self.clearConsole()
        frameCount = pyvizionsdk.VxGetFrameCount(cam)[1]
        print(f"FrameCount: {frameCount}\n")

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[" < Back to Timestamp Operations", "exit"],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Timestamp Operations
        if index == " < Back to Timestamp Operations":
            return self.Timestamp(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def ResetTimestamp(self, cam):
        self.clearConsole()
        pyvizionsdk.VxResetTimestamp(cam)

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[" < Back to Timestamp Operations", "exit"],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Timestamp Operations
        if index == " < Back to Timestamp Operations":
            return self.Timestamp(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def ResetFrameCount(self, cam):
        self.clearConsole()
        pyvizionsdk.VxResetFrameCount(cam)

        options = [
            inquirer.List('pyVizionCtl',
                          choices=[" < Back to Timestamp Operations", "exit"],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        # Back to Timestamp Operations
        if index == " < Back to Timestamp Operations":
            return self.Timestamp(cam)
        # exit
        elif index == "exit":
            # close the camera when exit
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def SensorConfig(self, cam):
        self.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                          message="Sensor Config Operations:",
                          choices=[
                              "Export sensor config", "Decode sensor config",
                              " < Back to Camera Control and Management Tool",
                              "exit"
                          ],
                          carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        if index == "Export sensor config":
            return self.ExportSensor(cam)
        elif index == "Decode sensor config":
            return self.DecodeSensor(cam)
        elif index == " < Back to Camera Control and Management Tool":
            return self.CtlList(cam)
        elif index == "exit":
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def ExportSensor(self, cam):
        self.clearConsole()
        filePath = input("Enter the File Path (e.g: config.bin): ")
        while not self.ValidFilePath(filePath, "bin"):
            filePath = input("Enter the File Path (e.g: config.bin): ")
        if pyvizionsdk.VxExportSensorConfig(cam, filePath) == 0:
            print("Save the sensor config to ", filePath)
        options = [
            inquirer.List(
                'pyVizionCtl',
                message="Export Sensor:",
                choices=[" < Back to Sensor Config Operations", "exit"],
                carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        if index == " < Back to Sensor Config Operations":
            return self.SensorConfig(cam)
        elif index == "exit":
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()

    def CheckFileExist(self, binPath):
        if not os.path.exists(binPath):
            print(
                "The binary file doesn't exist. Please ensure the binary path exists."
            )
            return False

        return True

    def DecodeSensor(self, cam):
        self.clearConsole()
        binPath = input("Enter the Binary File Path (e.g: config.bin): ")
        while not self.ValidFilePath(binPath, "bin") or not self.CheckFileExist(
                binPath):
            binPath = input("Enter the Binary File Path (e.g: config.bin): ")

        jsonPath = input("Enter the JSON File Path (e.g: config.json): ")
        while not self.ValidFilePath(jsonPath, "json"):
            jsonPath = input("Enter the JSON File Path (e.g: config.json): ")

        if pyvizionsdk.VxDecodeSensorConfig(binPath, jsonPath) == 0:
            print("Decode the sensor config to ", jsonPath)

        options = [
            inquirer.List(
                'pyVizionCtl',
                message="Decode Sensor:",
                choices=[" < Back to Sensor Config Operations", "exit"],
                carousel=True),
        ]
        result = self.OptionTerminal(options)
        index = result['pyVizionCtl']

        if index == " < Back to Sensor Config Operations":
            return self.SensorConfig(cam)
        elif index == "exit":
            self.clearConsole()
            pyvizionsdk.VxClose(cam)
            exit()


def main():
    try:
        pyCtl = pyVizionCtl()
        pyCtl.clearConsole()
        options = [
            inquirer.List('pyVizionCtl',
                        message="pyVizionCtl",
                        choices=["Device List", "exit"],
                        carousel=True),
        ]
        result = pyCtl.OptionTerminal(options)
        entryIndex = result['pyVizionCtl']

        if entryIndex == "Device List":
            pyCtl.GetDeviceList()
        elif (entryIndex == "exit"):
            pyCtl.clearConsole()
            exit()
    except KeyboardInterrupt:
        print("\nPrompt cancelled. Exiting...")
        sys.exit(0)

if __name__ == '__main__':
    main()
